<!-- LOGO DIREITO -->
<a href="#"><img width="200px" src="https://img.freepik.com/fotos-gratis/bandeira-do-brasil-fundo_135932-1335.jpg" align="right" /></a>

# Artigo

> **Nota:** aqui vai o shield do seu projeto. Para criar, basta editar asvariáveis do endereço de acordo com as preferências. Para os logos, seguir a lista do [Simple Icons](https://simpleicons.org/). Se não existir seu logo, ler a questão [How do I use the 'logo' option in shields.io badges?](https://stackoverflow.com/questions/38985050/how-do-i-use-the-logo-option-in-shields-io-badges) para melhor customização.
>
>```cmd
>https://img.shields.io/static/v1?label=<LABEL>&message=<MSG>&color=<COLOR>&logo=<LOGO>&logoColor=<COLOR>&labelColor=<COLOR>&style=flat
>```
>
>Ex.:
>
><p align="left">
>  <a href="https://github.com/JonathanTSilva/HL-Linux">
>    <img src="https://img.shields.io/static/v1?label=Home_Lab&message=Linux&color=green&logo=linux&logoColor=white&labelColor=grey&style=flat" alt="HL-Linux">
>  </a>
></p>

[EMOJI] Breve descrição do documento, com um emoji inicial.

<!-- SUMÁRIO -->
- [Artigo](#artigo)
  - [1. Capítulo](#1-capítulo)
    - [1.1. Seção](#11-seção)
      - [1.1.1. Subseção](#111-subseção)
        - [1.1.1.1. Tópico](#1111-tópico)

<!-- VOLTAR AO ÍNICIO -->
<a href="#"><img width="40px" src="https://github.com/JonathanTSilva/JonathanTSilva/blob/main/Images/back-to-top.png" align="right" /></a>

## 1. Capítulo

### 1.1. Seção

#### 1.1.1. Subseção

##### 1.1.1.1. Tópico

> **Nota:** aqui vai uma nota.

<!-- MARKDOWN LINKS -->
<!-- SITES -->
[A]: Aqui vai a URL do site1

<!-- IMAGES -->
[B]: Aqui vai o endereço da imagem1